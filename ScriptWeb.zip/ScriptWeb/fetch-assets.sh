#!/usr/bin/env bash
# Tải thư viện về để app chạy OFFLINE. Nếu lỗi, app tự dùng CDN (cần mạng).
set +e
cd "$(dirname "$0")/app/src/main/assets/www/lib" || exit 0
mkdir -p fa/css fa/webfonts
FA=https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0
curl -fsSL --retry 3 -o tailwind.js https://cdn.tailwindcss.com || rm -f tailwind.js
curl -fsSL --retry 3 -o fa/css/all.min.css $FA/css/all.min.css || rm -f fa/css/all.min.css
for f in fa-solid-900 fa-regular-400 fa-brands-400; do
  curl -fsSL --retry 3 -o fa/webfonts/$f.woff2 $FA/webfonts/$f.woff2 || rm -f fa/webfonts/$f.woff2
done
ls -la . fa/css fa/webfonts
exit 0
